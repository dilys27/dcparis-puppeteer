const Bot = require('./Bot');

const run = async()=>{

    const bot = new Bot();

    await bot.initPuppeteer().then(()=>console.log('Puppeteer est executé'));

    await bot.visitGithub().then(()=>console.log('Connexion sur GitHub réussie'));

    await bot.parseUsername().then(()=>console.log('Username parsé avec succès'));

    await bot.closeBrowser().then(()=>console.log('Navigateur fermé'))
}

run().catch(e=>console.log(e.message));