const firebase = require('firebase-admin');
const config = require('./config/db_config.json');

firebase.initializeApp({
    credential: firebase.credential.cert(config),
    databaseURL: "https://githubscraper-2ccb5.firebaseio.com"
});

let database = firebase.database();

const writeUserData = async (users)=>{
    const created_at = await new Date().getTime();
    await database.ref('users/'+created_at).set({
        username: users['name'],
        email: users['email'],
        created_at: created_at
    })
}

module.exports = {
    writeUserData,
};