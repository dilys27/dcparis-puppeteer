class GithubBot{

    constructor(){
        this.firebase = require('./firebase_db');
        this.config = require('./config/puppeteer.json');
    }

    async initPuppeteer(){
        const puppeteer = require('puppeteer');
        this.browser = await puppeteer.launch({
            headless: this.config.settings.headless
        });
        this.page = await this.browser.newPage();
        await this.page.setViewport({width:1500, height:764});
    }

    async visitGithub(){
        await this.page.goto(this.config.base_url);
        await this.page.waitForTimeout(2500);
        await this.page.click(this.config.selectors.home_to_login_button);
        await this.page.waitForTimeout(2500);
        //On accede a et on rempli l'input Username
        await this.page.click(this.config.selectors.username_field);
        await this.page.keyboard.type(this.config.username);
        //On accede a et on rempli l'input Password
        await this.page.click(this.config.selectors.password_field);
        await this.page.keyboard.type(this.config.password);
        //On clique sur le bouton login (input )
        await this.page.click(this.config.selectors.login_button);
    }

    async parseUsername(){
        await this.page.waitForTimeout(2000);
        const userToSearch = this.config.searchUsername;
        const searchUrl = `https://github.com/search?q=${userToSearch}&type=Users`;
        let users = new Map();

        await this.page.goto(searchUrl);
        await this.page.waitForTimeout(2500);

        let numPages = await this.numPages(this.page);
        console.log("Nombre de pages", numPages);

        if(numPages > this.config.settings.max_amount_pages);{
            numPages = this.config.settings.max_amount_pages;
        }

        for(let h = 1; h<numPages; h++){
            let pageUrl = searchUrl + '&p=' + h;
            await this.page.goto(pageUrl);
            
            let listLength = await this.page.evaluate((x)=>{
                return document.getElementsByClassName(x).length;
            }, this.config.selectors.length_selector);

            for(let i = 1; i<=listLength; i++){
                let usernameSelector = this.config.selectors.list_username.replace('INDEX',i);
                let emailSelector = this.config.selectors.list_email.replace('INDEX',i);

                let username = await this.page.evaluate((x)=>{
                    return document.querySelector(x).getAttribute('href').replace('/','');
                }, usernameSelector)

                let email = await this.page.evaluate((x)=>{
                    let element = document.querySelector(x);
                    return element ? element.innerHTML : null;
                }, emailSelector)

                if(!email){
                    continue;
                }
                console.log('Résultats', username, "->", email);

                users['name'] = username;
                users['email'] = email;

                console.log('Tableau', users);

                this.firebase.writeUserData(users);
            }
        }
    }

    async numPages(page){
        const num_user_selector = "#js-pjax-container > div > div > div > div > h3";
        let inner = await page.evaluate((x)=>{
            let html = document.querySelector(x).innerHTML;

            return html.replace(',','').replace('users','').trim();
        }, num_user_selector);

        const numUsers = parseInt(inner);
        return Math.ceil(numUsers/10);
    }

    async closeBrowser(){
        await this.browser.close();
    }
}

module.exports =GithubBot;