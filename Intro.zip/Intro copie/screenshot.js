const puppeteer = require("puppeteer");

//Declaration d'une fonction asynchrone
const getScreenshot = async() =>{
    //Création d'une instance de Chromium
    const browser = await puppeteer.launch({headless:false});
    //Ouverture d'un nouvel onglet
    const page = await browser.newPage();
    //Naviguer vers l'URL choisi
    const url = process.argv[2];
    await page.goto(url);
    //On vérifie que la page est bien chargée (await page.waitFor('body');)
    await page.waitForSelector('body');
    //On définie la taille de la fenêtre
    await page.setViewport({width:1920, height:1080});
    //On fait le screenshot et on l'enregistre
    await page.screenshot({path:"screenshot.png", fullPage:true});
    //On ferme l'instance de Chromium
    await browser.close();
}

getScreenshot();

//Autre moyen de déterminer l'url a scraper

//const url = process.argv[2]

//puis remplacer l'url dans la méthode goto par la constante url
//puis on entre la commande dans le terminal
//node screenshot.js <url>