const puppeteer = require('puppeteer');

//Création de la fonction getData

const getData = async() =>{
    
    const browser = await puppeteer.launch(); //{headless:false, slowMo:100}
    const page = await browser.newPage();

    //Aller sur http://books.toscrape.com/
    const url = "http://books.toscrape.com/";
    await page.goto(url, {waitUntil:"networkidle2"});
    await page.waitForSelector('body');

    //On clique sur le lien
    await page.click('#default > div > div > div > div > section > div:nth-child(2) > ol > li:nth-child(12) > article > h3 > a');
    
    //et récupérer le prix et le titre du livre puis les afficher dans la console
    const result = await page.evaluate(()=>{
        let prix = document.querySelector('#content_inner > article > div.row > div.col-sm-6.product_main > p.price_color').innerHTML;
        let titre = document.querySelector('#content_inner > article > div.row > div.col-sm-6.product_main > h1').innerHTML;
        
        return {titre, prix}
    });

    await browser.close();
    return result;
    //console.log("Le livre " + titre + " est au prix de " + prix + " £.");

}

getData().then(value=>{
    console.log(value)
});