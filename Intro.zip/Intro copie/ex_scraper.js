const { rejects } = require('assert');
const { utimes } = require('fs');
const { resolve } = require('path')
const puppeteer = require('puppeteer');

function run(pagesToScrape = 1){
    return new Promise(async (resolve, reject) =>{
        try{
            const browser = await puppeteer.launch(); //{headless:false, slowMo:100}
            const page = await browser.newPage();
            await page.goto('http://books.toscrape.com/');
            let currentPage = 1;
            let urls = [];

            while(currentPage <= pagesToScrape){
                let newUrls = await page.evaluate(()=>{
                    let results = [];
                    let items = document.querySelectorAll('article.product_pod');
                    items.forEach((item) =>{
                        results.push({
                            title: item.querySelector('h3 a').getAttribute('title'),
                            price: item.querySelector('p.price_color').innerHTML,
                            url: item.querySelector('h3 a').getAttribute('href')
                        });
                    });
                    return results;
                });
                urls = urls.concat(newUrls);
                if(currentPage < pagesToScrape){
                    await Promise.all([
                        await page.click('li.next'),
                        await page.waitForSelector('article.product_pod')
                    ])
                }
                currentPage++;
            }
            browser.close();
            return resolve(urls);
        } catch(e){
            return reject(e);
        }
    })
}

run(2).then(console.log).catch(console.error);