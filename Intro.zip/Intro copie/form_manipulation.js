const puppeteer = require("puppeteer");

const sendMail = async() =>{
    const browser = await puppeteer.launch({headless:false, slowMo:100});
    const page = await browser.newPage();

    //Acceder a la page ou se trouve le formulaire de contact
    await page.goto('https://keiturna.fr', {waitUntil:"networkidle2"});

    //Entrer le nom
    await page.focus('#name');
    await page.keyboard.type('PuppeteerBot');
    
    //Entrer le mail
    await page.focus('#email');
    await page.keyboard.type('PuppeteerBot@mail.com');

    //Entrer le message
    await page.focus('#contact-section > div:nth-child(3) > form > div:nth-child(7) > div.col.span-2-of-3 > textarea');
    await page.keyboard.type('Hello World')

    //Cliquer sur le bouton submit
    //await page.click('#contact-section > div:nth-child(3) > form > div:nth-child(8) > div.col.span-2-of-3 > input[type=submit]');

    await browser.close();
}

sendMail();