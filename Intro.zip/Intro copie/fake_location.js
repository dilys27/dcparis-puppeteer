const puppeteer = require('puppeteer');

const setFakeLocation = async() =>{
    const browser = await puppeteer.launch({headless:false, slowMo:100});
    const screenshotPath = "location.png";
    let url = "https://www.google.fr/maps/";

    //Outrepasser les permissions pour ne pas avoir à cliquer sur "J'accepte la géoloc"
    const context = await browser.defaultBrowserContext();
    await context.overridePermissions(url, ['geolocation']);

    const page = await browser.newPage();

    //A chaque fois que la géoloc sera demandé, elle sera remplie avec la latitude et la longitude renseignées
    await page.evaluateOnNewDocument(function () {
        navigator.geolocation.getCurrentPosition =function(cb){
            SetTimeout(() =>{
                cb({
                    'coords':{
                        accuracy:21,
                        altitude:null,
                        altitudeAccuracy:null,
                        heading:null,
                        latitude:34.052235,
                        longitude:-118.243683,
                        speed:null
                    }
                })
            }, 1000)
        }
    });

    await page.goto(url, {waitUntil:"networkidle2"});
    //await page.setViewport({width:1920, height:1080});

    let closeModalBtn = page.$('#introAgreeButton');
    process.exit(closeModalBtn);
    
    await page.screenshot({path: screenshotPath});
}

setFakeLocation();