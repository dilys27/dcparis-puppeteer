const puppeteer = require('puppeteer');

//On ajoute l'argument pagesToScrape à notre fonction.
//Il permettra de définir la limite de pages à scraper
function run(pagesToScrape){
    return new Promise(async (resolve, reject) =>{
        try{
            //On conditionne pour éviter les erreurs en cas de non spécification de l'argument
            if(!pagesToScrape){
                pagesToScrape = 1;
            }

            const browser = await puppeteer.launch(); //{headless:false, slowMo:100}
            const page = await browser.newPage();
            await page.goto('https://news.ycombinator.com/');

            //On détermine la page actuelle, autrement dit la 1ère page du scraping
            let currentPage = 1;
            let urls = [];

            //On encapsule la fonction evaluate() dans une boucle while qui va tourner tant que la
            //currentPage est inférieur ou égal à pagesToScrape
            while(currentPage <= pagesToScrape){
                let newUrls = await page.evaluate(()=>{
                    let results = [];
                    //Tous les elts avec la classe 'a.storylink'
                    let items = document.querySelectorAll('tr.athing'); //document.querySelectorAll('a.storylink'); 
                    items.forEach((item) =>{
                        results.push({
                            rank: item.querySelector('span.rank').innerHTML,
                            url: item.querySelector('td.title a').getAttribute('href'), //url: item.getAttribute('href'),
                            text: item.querySelector('td.title a').innerHTML
                        });
                    });
                    return results;
                });
                urls = urls.concat(newUrls);
                if(currentPage < pagesToScrape){
                    await Promise.all([
                        //On ajoute la fonction page.click() pour accéder au bouton More
                        await page.click('a.morelink'),
                        //On vérifie que l'élément a.storylink est chargé avec la fonction waitForSelector
                        await page.waitForSelector('a.storylink')
                    ])
                }
                //On incrémente la variable currentPage pour finir la boucle
                currentPage++;
            }
            browser.close();
            return resolve(urls);
        } catch(e){
            return reject(e);
        }
    })
}

run(4).then(console.log).catch(console.error);