const puppeteer = require("puppeteer");

const searchOn = async() =>{
    const browser = await puppeteer.launch({headless:false, slowMo:100});
    const page = await browser.newPage();
    //On définie la taille de la fenêtre
    await page.setViewport({width:1200, height:800});
    
    //Texte à rechercher
    const text = process.argv[2];

    //Acceder a la page
    let url = 'https://www.lemonde.fr/'
    await page.goto(url, {waitUntil:"networkidle2"});

    //On clique sur J'accepte les cookies
    await page.click('#iubenda-cs-banner > div > div > div > div.iubenda-cs-opt-group > div.iubenda-cs-opt-group-consent > button');

    //On accède à la page de connexion
    await page.click('#Header > header > div > div.right > div > a.Header__connexion.js-header-login > span.login-info');

    //On entre le mail et le mdp de connexion puis on clique sur Se connecter
    await page.waitForSelector('#connection_mail') //Important pour laisser charger la page
    await page.focus('#connection_mail');
    await page.keyboard.type('leblancdilys@yahoo.fr');

    await page.focus('#connection_password');
    await page.keyboard.type('DCPARIStest123');

    await page.click('#connection_save');

    //On clique sur la loupe pour faire une recherche
    await page.click('#nav-markup > li:nth-child(11) > a');

    //On outrepasse les permissions pour ne pas avoir à cliquer sur "J'accepte les notifs"
    const context = await browser.defaultBrowserContext();
    await context.overridePermissions(url, ['notifications']);

    //On entre dans la barre de recherche le texte mis en argument
    await page.waitForSelector('#search_keywords')
    await page.focus('#search_keywords');
    await page.keyboard.type(text);

    //Cliquer sur le bouton Rechercher
    await page.waitForSelector('#form-live-submit')
    await page.click('#form-live-submit');
    
    run(browser, page, process.argv[3]).then(console.log).catch(console.error);

    //browser.close();
}

function run(browser, page, pagesToScrape = 1) {
    return new Promise(async (resolve, reject) =>{
        try{
            let currentPage = 1;
            let urls = [];
    
            while(currentPage <= pagesToScrape){
                await page.waitForSelector('section.js-river-search')
                let newUrls = await page.evaluate(()=>{
                    let results = [];
                    let items = document.querySelectorAll('section.teaser teaser--inline-picture');
                    items.forEach((item) =>{
                        results.push({
                            title: item.querySelector('h3.teaser__title').innerHTML,
                            desc: item.querySelector('p.teaser__desc').innerHTML,
                            date: item.querySelector('p.meta__publisher meta--page span.meta__date').innerHTML,
                            author: item.querySelector('p.meta__publisher meta--page span.meta__author meta__author--page').innerHTML,
                            url: item.querySelector('a.teaser__link teaser__link--kicker').getAttribute('href')
                        });
                    });
                    return results;
                });
                urls = urls.concat(newUrls);             
                if(currentPage < pagesToScrape){
                    await page.waitForTimeout(2500);
                    let pages = await page.evaluate(()=>{
                        return document.querySelectorAll('section.river__pagination a')
                    });
                    console.log('Pages : '+pages.childNodes)
                    await Promise.all([
                        await page.click(pages.childNodes[currentPage+1]),
                        await page.waitForSelector('section.js-river-search')
                    ])
                }
                currentPage++;
            }
            browser.close();
            return resolve(urls);
        } catch(e){
            return reject(e);
        }
    })
}

searchOn();