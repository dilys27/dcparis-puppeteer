/* 
Acceder a Instagram -> via la page de base : https://instagram.com
S'y connecter
Rechercher un hashtag (./explore/tags/[tag])
Liker et s'abonner aux users des 9 photos "Meilleurs publications"
Enregistrer les utilisateurs que l'on follow sur Firebase

****!!!!!!****
Quand le script passe sur une photo deja liké ou un utilisateur deja follow, il ne doit pas reclicker sur le bouton pour ne pas unlike ou unfollow
Attention a bien utiliser le systeme de class et de méthode vu sur l'exercice GitHub
*/

const Bot = require('./Bot');

const run = async()=>{

    const bot = new Bot();

    await bot.initPuppeteer().then(()=>console.log('Puppeteer est executé'));

    await bot.visitInstagram().then(()=>console.log('Connexion sur Instagram réussie'));

    await bot.searchHashtags().then(()=>console.log('Les hashtags ont bien été recherchés et likés'));

    await bot.closeBrowser().then(()=>console.log('Navigateur fermé'))
}

run().catch(e=>console.log(e.message));