class InstagramBot{

    constructor(){
        this.firebase = require('./firebase_db');
        this.config = require('./config/puppeteer.json');
    }

    async initPuppeteer(){
        const puppeteer = require('puppeteer');
        this.browser = await puppeteer.launch({
            headless: this.config.settings.headless
        });
        this.page = await this.browser.newPage();
        await this.page.setViewport({width:1500, height:764});
    }

    async visitInstagram(){
        await this.page.goto(this.config.base_url);
        await this.page.waitForTimeout(2500);
        //On accede a et on rempli l'input Username
        await this.page.click(this.config.selectors.username_field);
        await this.page.keyboard.type(this.config.username);
        //On accede a et on rempli l'input Password
        await this.page.click(this.config.selectors.password_field);
        await this.page.keyboard.type(this.config.password);
        //On clique sur le bouton login
        await this.page.click(this.config.selectors.login_button);
        //On clique sur le bouton Plus tard pour ne pas enregistrer nos identifiants
        await this.page.waitForTimeout(2500);
        await this.page.click(this.config.selectors.register_login_later);
        //On clique sur le bouton Plus tard pour ne pas activer les notifications
        await this.page.waitForTimeout(2500);
        await this.page.click(this.config.selectors.activate_notification_later);
        //Outrepasser les permissions
        const context = await this.browser.defaultBrowserContext();
        await context.overridePermissions(this.config.base_url, ['notifications']);
    }

    async searchHashtags(){
        const hashToSearch = this.config.searchHashtags;
        for(let i=0; i<hashToSearch.length; i++){
            let hash = hashToSearch[i];
            console.log('Hash to search :', hash)
            await this.page.waitForTimeout(2500);
            const searchUrl = `https://www.instagram.com/explore/tags/${hash}/`;
            let users = new Map();
    
            await this.page.goto(searchUrl);
            await this.page.waitForTimeout(2500);
            
            //J'accede à la liste des meilleurs publications avec le 1er element
            let publicationSelector = this.config.selectors.list_publication;
            await this.page.click(publicationSelector);
    
            for(let h = 1; h<=this.config.settings.max_amount_publications; h++){

                //Je clique sur 'J'aime' si pas deja cliquer en comparant l'attribut 'fill'
                await this.page.waitForTimeout(2500);
                let fillLikeButton = await this.page.evaluate((x)=>{
                    return document.querySelector(x).getAttribute('fill').innerHTML;
                }, this.config.selectors.like_button)
                if(fillLikeButton != this.config.fill_like){
                    await this.page.click(this.config.selectors.like_button);
                }

                //Je m'abonne si pas deja abonné
                await this.page.waitForTimeout(2500);
                let textSubscribeButton = await this.page.evaluate((x)=>{
                    return document.querySelector(x).innerHTML;
                }, this.config.selectors.subscribe_button);
                if(textSubscribeButton != this.config.text_subscription){
                    await this.page.click(this.config.selectors.subscribe_button);
                }

                //Je met le username dans la base de donnée Firebase
                let username = await this.page.evaluate((x)=>{
                    return document.querySelector(x).innerHTML;
                }, this.config.selectors.list_username);
                console.log('Résultats', username);
                users['name'] = username;
    
                console.log('Tableau', users);
    
                this.firebase.writeUserData(users);

                //Je clique sur le bouton suivant pour acceder a la publication suivante
                await this.page.waitForTimeout(2500);
                await this.page.click(this.config.selectors.next_button);
            }
        }
    }

    async closeBrowser(){
        await this.browser.close();
    }
}

module.exports = InstagramBot;